export interface Produtos{
    nome: string;
    preco: string;
    descricao: string;
    emEstoque: boolean;
}